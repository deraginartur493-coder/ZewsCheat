package com.zews.zews

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = Color.rgb(10, 8, 18)
    private val panel = Color.rgb(25, 18, 40)
    private val purple = Color.rgb(174, 92, 255)
    private lateinit var status: TextView
    private lateinit var reactionButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(28))
        }
        scroll.addView(page)

        val logo = TextView(this).apply {
            text = "ZEWS\\nCHEAT"
            textSize = 32f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
            gravity = Gravity.CENTER
            letterSpacing = 0.12f
        }
        page.addView(logo, matchWrap())

        val subtitle = TextView(this).apply {
            text = "TRAINING & SETTINGS  •  VERSION 1.0"
            textSize = 11f
            setTextColor(purple)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(22))
            letterSpacing = 0.08f
        }
        page.addView(subtitle, matchWrap())

        page.addView(section("ПАНЕЛЬ НАСТРОЕК"))
        addSwitch(page, "Настройка чувствительности", "Локальная настройка-памятка")
        addSwitch(page, "Профиль HUD", "Сохранение выбранного режима в приложении")
        addSwitch(page, "Тренировка реакции", "Включить тренировочный раздел")
        addSwitch(page, "Компактный интерфейс", "Уменьшенный вид меню")

        page.addView(section("ТРЕНИРОВКА РЕАКЦИИ"))
        val info = TextView(this).apply {
            text = "Нажми кнопку, когда она станет фиолетовой. Это простая тренировка реакции внутри ZewsCheat."
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = rounded(panel, 16)
        }
        page.addView(info, matchWrap())

        status = TextView(this).apply {
            text = "Готов к тренировке?"
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, dp(10))
        }
        page.addView(status, matchWrap())

        reactionButton = Button(this).apply {
            text = "НАЧАТЬ ТРЕНИРОВКУ"
            textSize = 13f
            setTextColor(Color.WHITE)
            background = rounded(purple, 14)
            setOnClickListener {
                status.text = "Отлично! Тренировочный режим — демонстрационный."
                Toast.makeText(this@MainActivity, "Тренировка запускается внутри приложения", Toast.LENGTH_SHORT).show()
            }
        }
        page.addView(reactionButton, LinearLayout.LayoutParams(-1, dp(54)).apply {
            topMargin = dp(8)
        })

        val footer = TextView(this).apply {
            text = "DEMO APP • НЕ ПОДКЛЮЧАЕТСЯ К PUBG MOBILE"
            textSize = 10f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            setPadding(0, dp(26), 0, 0)
        }
        page.addView(footer, matchWrap())

        setContentView(scroll)
    }

    private fun addSwitch(parent: LinearLayout, title: String, description: String) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = rounded(panel, 14)
        }
        val toggle = Switch(this).apply {
            text = title
            textSize = 15f
            setTextColor(Color.WHITE)
            buttonTintList = android.content.res.ColorStateList.valueOf(purple)
            thumbTintList = android.content.res.ColorStateList.valueOf(purple)
            isChecked = false
        }
        card.addView(toggle, matchWrap())
        val hint = TextView(this).apply {
            text = description
            textSize = 11f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(4), 0, 0)
        }
        card.addView(hint, matchWrap())
        parent.addView(card, matchWrap().apply { bottomMargin = dp(10) })
    }

    private fun section(text: String) = TextView(this).apply {
        this.text = text
        textSize = 12f
        setTextColor(purple)
        typeface = Typeface.DEFAULT_BOLD
        letterSpacing = 0.08f
        setPadding(dp(2), dp(18), 0, dp(10))
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radius).toFloat()
        }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
